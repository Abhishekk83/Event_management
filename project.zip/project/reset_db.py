import sqlite3

DATABASE = 'event_management.db'

def reset_db():
    """Drop existing tables and initialize the database."""
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('DROP TABLE IF EXISTS admin')
    cursor.execute('DROP TABLE IF EXISTS vendor')
    conn.commit()
    conn.close()

if __name__ == '__main__':
    reset_db()
