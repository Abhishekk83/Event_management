import sqlite3
from werkzeug.security import generate_password_hash

DATABASE = 'event_management.db'

def get_db_connection():
    """Connect to the SQLite database."""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Create tables and insert initial data."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('DROP TABLE IF EXISTS admin')
    cursor.execute('DROP TABLE IF EXISTS vendor')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS admin (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )
    ''')
    
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS vendor (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        category TEXT NOT NULL
    )
    ''')
    
    hashed_admin_password = generate_password_hash('adminpassword')
    cursor.execute('''
    INSERT OR IGNORE INTO admin (user_id, password)
    VALUES (?, ?)
    ''', ('admin', hashed_admin_password))
    
    conn.commit()
    conn.close()

def get_user_password(user_id):
    """Retrieve the password hash for a given user ID from both admin and vendor tables."""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT password FROM admin WHERE user_id = ?', (user_id,))
    row = cursor.fetchone()
    
    if row:
        conn.close()
        return row['password']
    
    cursor.execute('SELECT password FROM vendor WHERE email = ?', (user_id,))
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return row['password']
    
    return None

def add_vendor(name, email, password, category):
    """Add a new vendor to the database."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
    INSERT INTO vendor (name, email, password, category)
    VALUES (?, ?, ?, ?)
    ''', (name, email, password, category))
    conn.commit()
    conn.close()
