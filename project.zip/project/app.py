from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash
import os
from db import get_db_connection, init_db, get_user_password, add_vendor

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a real secret key

# Configure the path to your stylesheet directory
app.config['STYLESHEET_FOLDER'] = 'static'

# Initialize the database
def setup():
    """Initialize the database."""
    init_db()

setup()  # Call the setup function

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        user_id = request.form['user-id']
        password = request.form['password']

        stored_password = get_user_password(user_id)
        if stored_password and check_password_hash(stored_password, password):
            session['user_id'] = user_id
            return redirect(url_for('dashboard'))
        else:
            return 'Invalid login credentials', 401

    return render_template('admin_login.html')

@app.route('/vendor-signup', methods=['GET', 'POST'])
def vendor_signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        category = request.form['category']
        
        hashed_password = generate_password_hash(password)
        add_vendor(name, email, hashed_password, category)
        
        return redirect(url_for('home'))
    
    return render_template('vendor_signup.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' in session:
        return f'Hello, {session["user_id"]}!'
    return redirect(url_for('home'))

@app.route('/static/<path:filename>')
def custom_static(filename):
    return send_from_directory(app.config['STYLESHEET_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True)